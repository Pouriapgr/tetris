package canvas;

import canvas.Canvas;
import canvas.Constants;
import canvas.GameState;

import javax.swing.*;

public class Start {
    public static void main(String[] args) {
        GameState gameState = GameState.getInstance();
        Canvas canvas = new Canvas();
        setFrame(canvas);
    }
    private static void setFrame(Canvas canvas){
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.getContentPane().add(canvas);
        frame.setSize(Constants.FRAME_WIEDTH, Constants.FRAME_HEIGHT);
        frame.setTitle("Tetarisio");
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);
    }
}
