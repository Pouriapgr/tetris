package pieces;

import canvas.Cell;
import canvas.Constants;
import canvas.GameState;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class Stick extends AllPieces{

    public Stick(int id,int box_size){
        super(id, box_size);
        box[0][2].setColor(color);
        box[1][2].setColor(color);
        box[2][2].setColor(color);
        box[3][2].setColor(color);
    }

    @Override
    public boolean canRotate(){
        gameState = GameState.getInstance();
        Cell[][] help_box= this.rotatePiece();
        Cell[][] cells = gameState.getBoard().getCells();
        for(int i = 0; i < box_size; i++) {
            for (int j = 0; j < box_size; j++) {
                if(help_box[i][j].getOccupied() == false)
                    continue;
                int X = help_box[i][j].getX();
                int Y = help_box[i][j].getY();
                if(X < 0 || Y < 0 || Y >= Constants.TABLE_WEIDTH)
                    return false;
                if(cells[X][Y].getId() == 0)
                    continue;
                if(cells[X][Y].getOccupied() && cells[X][Y].getId() != this.getId())
                    return false;
            }
        }
        return true;
    }

    @Override
    public Cell[][] rotatePiece(){
        Cell[][] help_box = new Cell[box_size][box_size];
        for(int i = 0; i < box_size; i++) {
            for (int j = 0; j < box_size; j++) {
                help_box[i][j] = new Cell(box[i][j].getX(), box[i][j].getY(), box[i][j].getI1(), box[i][j].getI2(),
                        box[i][j].getWEIDTH(), box[i][j].getHeight(), Constants.CELL_INITIAL_COLOR, false,
                        box[i][j].getId());
            }
        }
        help_box[0][0].setCell(box[0][3]);
        help_box[0][3].setCell(box[3][3]);
        help_box[3][3].setCell(box[3][0]);
        help_box[3][0].setCell(box[0][0]);
        help_box[0][1].setCell(box[1][3]);
        help_box[1][3].setCell(box[3][2]);
        help_box[3][2].setCell(box[2][0]);
        help_box[2][0].setCell(box[0][1]);
        help_box[0][2].setCell(box[2][3]);
        help_box[2][3].setCell(box[3][1]);
        help_box[3][1].setCell(box[1][0]);
        help_box[1][0].setCell(box[0][2]);
        help_box[1][1].setCell(box[1][2]);
        help_box[1][2].setCell(box[2][2]);
        help_box[2][2].setCell(box[2][1]);
        help_box[2][1].setCell(box[1][1]);
        return help_box;
    }
}
