package canvas;

import pieces.AllPieces;

import javax.swing.*;
import java.util.ArrayList;

public class GameState {
    private static GameState gameState;
    private ArrayList<AllPieces> pieces;
    private AllPieces currentPiece;
    private AllPieces currentPieceClone;
    private Board board;
    private int score = 0;
    private int pieceId = 1;
    private int rowsDestroyed = 0;
    private boolean gameOver = false;

    private GameState() {
        this.gameState = this;
        pieces = new ArrayList<>();
        board = new Board();
    }

    public static GameState getInstance(){
        if(gameState == null) gameState = new GameState();
        return gameState;
    }

    public ArrayList<AllPieces> getPieces(){
        return this.pieces;
    }
    public AllPieces getCurrentPiece(){
        return this.currentPiece;
    }
    public AllPieces getCurrentPieceClone() { return this.currentPieceClone; }
    public Board getBoard(){
        return this.board;
    }
    public int getScore(){ return this.score; }
    public int getPieceId(){ return this.pieceId; }
    public int getRowsDestroyed(){ return this.rowsDestroyed; }
    public boolean getGameOver(){ return this.gameOver; }

    public void setCurrentPiece(AllPieces currentPiece){
        if(currentPiece != null)
            setCurrentPieceClone(currentPiece.clonePiece());
        else
            setCurrentPieceClone(null);
        this.currentPiece = currentPiece;
    }
    public void setCurrentPieceClone(AllPieces currentPieceClone) { this.currentPieceClone = currentPieceClone; }
    public void setScore(int score){ this.score = score; }
    public void setGameOver(boolean gameOver){ this.gameOver = gameOver; }

    public void addRowsDestroyed(){ this.rowsDestroyed++; }
    public void addPieceId(){
        this.pieceId++;
    }
    public void addPiece(AllPieces piece){
        this.pieces.add(piece);
    }
    public void removePiece(AllPieces piece){
        this.pieces.remove(piece);
    }
}
