package pieces;

public class RightLeg extends Pieces {
    public RightLeg(int id, int box_size){
        super(id, box_size);
        box[0][1].setColor(color);
        box[1][1].setColor(color);
        box[2][1].setColor(color);
        box[2][2].setColor(color);
    }
}
