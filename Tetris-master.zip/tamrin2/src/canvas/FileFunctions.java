package canvas;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class FileFunctions {

    private static File getScoresFile(){
        String destination = System.getProperty("user.dir") + "/src/Scores.txt";
        File scores = new File(destination);
        if(scores.exists())
            return scores;
        try {
            scores.createNewFile();
            ArrayList<Integer> scores1 = new ArrayList<>();
            for(int i = 1; i <= Constants.NUMBER_OF_BEST_SCORES; i++)
                scores1.add(0);
            writeBestScores(scores1);
            return scores;
        }
        catch (Exception e){
            System.out.println("CANT MAKE SCORES FILE");
        }
        return scores;
    }

    public static ArrayList<Integer> bestScores(){
        ArrayList<Integer> scores = new ArrayList<>();

        try {
            File myfile = getScoresFile();
            Scanner myReader = new Scanner(myfile);
            while (myReader.hasNext()){
                String string = myReader.next();
                int score = Integer.parseInt(string);
                scores.add(score);
            }
            myReader.close();
            return scores;
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
            System.out.println("CANT READ SCORES");
        }
        return scores;
    }

    public static void writeBestScores(ArrayList<Integer> scores){
        try {
            File myfile = getScoresFile();
            FileWriter myWriter = new FileWriter(myfile);
            for(int x : scores){
                myWriter.write(Integer.toString(x));
                myWriter.write(System.getProperty("line.separator"));
            }
            myWriter.close();
        }
        catch (Exception e){
            System.out.println("CANT WRITE SCORES");
        }
    }
}
