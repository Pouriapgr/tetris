package canvas;

import canvas.Board;
import canvas.Cell;
import canvas.Constants;
import pieces.AllPieces;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Drawer {
    private Graphics2D graphics2D;
    private GameState gameState = GameState.getInstance();
    private Board board = gameState.getBoard();
    private Cell[][] cells = board.getCells();

    public Drawer() {}

    private void fillRectangle(int x, int y, int width, int height, Color color){
        graphics2D.setColor(color);
        graphics2D.fillRect(x,y,width,height);
    }

    private void fillOval(int x, int y, int width, int height, Color color){
        graphics2D.setColor(color);
        graphics2D.fillOval(x,y,width,height);
    }

    public void drawGameState(){
        gameState = GameState.getInstance();
        board = gameState.getBoard();
        cells = gameState.getBoard().getCells();
        fillRectangle(Constants.BACKGROUND_I1, Constants.BACKGROUND_I2, Constants.BACKGROUND_WEIDTH,
                Constants.BACKGROUND_HEIGHT, Constants.BACKGROUND_COLOR);

        board.update();
        for(int i = 0; i < Constants.TABLE_HEIGHT; i++){
            for(int j = 0; j < Constants.TABLE_WEIDTH; j++){
                Cell cell = cells[i][j];
                fillRectangle(cell.getI1(), cell.getI2(), cell.getWEIDTH(), cell.getHeight(), cell.getColor());
            }
        }
        drawMinors();
    }

    private void drawMinors(){
        drawScore();
        drawRemoved();
    }

    private void drawScore(){
        gameState = GameState.getInstance();

        graphics2D.setColor(Color.RED);
        String prompt = "Score";
        Font font = new Font(Constants.FONT_NAME, Font.BOLD, Constants.FONT_SIZE/2);
        FontMetrics fontMetrics = graphics2D.getFontMetrics(font);
        int width = fontMetrics.stringWidth(prompt);
        graphics2D.setFont(font);
        graphics2D.drawString(prompt, Constants.BACKGROUND_WEIDTH +
                (Constants.FRAME_WIEDTH - Constants.BACKGROUND_WEIDTH - width)/2,100);

        graphics2D.setColor(Color.ORANGE);
        prompt = Integer.toString(gameState.getScore());
        width = fontMetrics.stringWidth(prompt);
        graphics2D.drawString(prompt, Constants.BACKGROUND_WEIDTH +
                (Constants.FRAME_WIEDTH - Constants.BACKGROUND_WEIDTH - width)/2,130);
    }

    private void drawRemoved(){
        gameState = GameState.getInstance();

        graphics2D.setColor(Color.RED);
        String prompt = "Removed";
        Font font = new Font(Constants.FONT_NAME, Font.BOLD, Constants.FONT_SIZE/2);
        FontMetrics fontMetrics = graphics2D.getFontMetrics(font);
        int width = fontMetrics.stringWidth(prompt);
        graphics2D.setFont(font);
        graphics2D.drawString(prompt, Constants.BACKGROUND_WEIDTH +
                (Constants.FRAME_WIEDTH - Constants.BACKGROUND_WEIDTH - width)/2,180);

        graphics2D.setColor(Color.ORANGE);
        prompt = Integer.toString(gameState.getRowsDestroyed());
        width = fontMetrics.stringWidth(prompt);
        graphics2D.drawString(prompt, Constants.BACKGROUND_WEIDTH +
                (Constants.FRAME_WIEDTH - Constants.BACKGROUND_WEIDTH - width)/2,210);
    }


    public void drawGameOver(){
        gameState = GameState.getInstance();

        String prompt = "To Bakhti :)";
        Font font = new Font(Constants.FONT_NAME, Font.BOLD, Constants.FONT_SIZE);
        FontMetrics fontMetrics = graphics2D.getFontMetrics(font);
        int width = fontMetrics.stringWidth(prompt);
        graphics2D.setFont(font);
        graphics2D.drawString(prompt, (Constants.FRAME_WIEDTH - width) / 2, 200);
        drawYourScore();
        drawHighScores();
    }

    private void drawYourScore(){
        gameState = GameState.getInstance();

        Font font = new Font(Constants.FONT_NAME, Font.BOLD, Constants.FONT_SIZE / 2);
        FontMetrics fontMetrics = graphics2D.getFontMetrics(font);
        graphics2D.setColor(Color.RED);
        graphics2D.setFont(font);
        String prompt = "SCORE";
        int width = fontMetrics.stringWidth(prompt);
        graphics2D.drawString(prompt, (Constants.FRAME_WIEDTH - width) / 2, 300);


        graphics2D.setColor(Color.ORANGE);
        prompt = Integer.toString(gameState.getScore());
        width = fontMetrics.stringWidth(prompt);
        graphics2D.drawString(prompt, (Constants.FRAME_WIEDTH - width) / 2, 330);
    }

    private void drawHighScores(){
        gameState = GameState.getInstance();

        Font font = new Font(Constants.FONT_NAME, Font.BOLD, 30);
        FontMetrics fontMetrics = graphics2D.getFontMetrics(font);
        graphics2D.setColor(Color.BLACK);
        graphics2D.setFont(font);
        String prompt = "HIGHEST SCORERS";
        int width = fontMetrics.stringWidth(prompt);
        graphics2D.drawString(prompt, (Constants.FRAME_WIEDTH - width) / 2, 400);

        ArrayList<Integer> scores = FileFunctions.bestScores();
        Collections.sort(scores);
        for (int i = scores.size() - 1; i >= 0; i--) {
            font = new Font(Constants.FONT_NAME, Font.BOLD, Constants.FONT_SIZE/2);
            fontMetrics = graphics2D.getFontMetrics(font);
            graphics2D.setColor(Color.BLACK);
            graphics2D.setFont(font);
            int number = scores.size() - i;
            prompt = Integer.toString(number) + "- " + Integer.toString(scores.get(i));
            width = fontMetrics.stringWidth(prompt);
            graphics2D.drawString(prompt, (Constants.FRAME_WIEDTH - width) / 2, 400 + number * 30);
        }
    }

    public void setGraphics2D(Graphics2D graphics2D) {
        this.graphics2D = graphics2D;
    }
}
