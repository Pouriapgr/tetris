package canvas;

import pieces.AllPieces;

import java.awt.*;
import java.util.ArrayList;

public class Board {
    private Cell[][] cells;
    private GameState gameState = GameState.getInstance();

    public Board(){ initializeCells(); }

    private void initializeCells(){
        cells = new Cell[Constants.TABLE_HEIGHT][Constants.TABLE_WEIDTH];
        int i2 = Constants.TABLE_I2;
        for(int i = 0; i < Constants.TABLE_HEIGHT; i++){
            int i1 = Constants.TABLE_I1;
            for(int j = 0; j < Constants.TABLE_WEIDTH; j++){
                cells[i][j] = new Cell(i, j, i1, i2, Constants.CELL_WEIDTH, Constants.CELL_HEIGHT,
                        Constants.CELL_INITIAL_COLOR, false, 0);
                i1 += Constants.CELL_WEIDTH + Constants.CELL_SEPERATOR;
            }
            i2 += Constants.CELL_HEIGHT + Constants.CELL_SEPERATOR;
        }
    }

    public void update(){
        gameState = GameState.getInstance();
        initializeCells();
        ArrayList<AllPieces> pieces = gameState.getPieces();

        for (AllPieces piece : pieces){
            if (piece == null)
                continue;

            Cell[][] box = piece.getBox();
            for (int i = 0; i < piece.getBoxSize(); i++){
                for (int j = 0; j < piece.getBoxSize(); j++){
                    Cell cell = box[i][j];
                    if(cell.getX() < 0 || cell.getY() < 0 || cell.getY() >= Constants.TABLE_WEIDTH)
                        continue;
                    if(cell.getOccupied() == false)
                        continue;
                    cells[cell.getX()][cell.getY()].setColor(cell.getColor());
                    cells[cell.getX()][cell.getY()].setId(cell.getId());
                }
            }
        }
    }

    public boolean removeRow(){
        gameState = GameState.getInstance();
        for (int i = Constants.TABLE_HEIGHT - 1; i >= 0; i--){
            boolean isAllPiece = true;
            for(int j = 0; j < Constants.TABLE_WEIDTH; j++)
                if(cells[i][j].getId() == 0)
                    isAllPiece = false;
            if(isAllPiece == false)
                continue;
            gameState.addRowsDestroyed();
            remove(i);
            moveAllDown(i);
            return true;
        }
        return false;
    }

    private void moveAllDown(int i){
        for (int i1 = i - 1; i1 >= 0; i1--){
            for (int j = 0; j < Constants.TABLE_WEIDTH; j++){
                if(cells[i1][j].getId() == 0)
                    continue;
                AllPieces piece = findPiece(cells[i1][j].getId());
                if(piece == null)
                    continue;
                Cell[][] box = piece.getBox();
                int box_size = piece.getBoxSize();
                for(int l1 = 0; l1 < box_size; l1++)
                    for(int l2 = 0; l2 < box_size; l2++)
                        if(box[l1][l2].getX() == i1 && box[l1][l2].getY() == j)
                            box[l1][l2].setX(i1 + 1);
            }
            update();
        }
    }

    private void remove(int i){
        gameState = GameState.getInstance();
        for(int j = 0; j < Constants.TABLE_WEIDTH; j++){
            Cell cell = cells[i][j];
            int id = cell.getId();
            AllPieces piece = findPiece(id);
            if(piece == null)
                continue;
            Cell[][] box = piece.getBox();
            int box_size = piece.getBoxSize();
            for(int l1 = 0; l1 < box_size; l1++)
                for(int l2 = 0; l2 < box_size; l2++)
                    if(box[l1][l2].getX() == i && box[l1][l2].getY() == j)
                        box[l1][l2].setColor(Constants.CELL_INITIAL_COLOR);
            if(piece.isPresent() == false)
                gameState.removePiece(piece);
        }
    }

    private AllPieces findPiece(int id){
        gameState = GameState.getInstance();
        ArrayList<AllPieces> pieces = gameState.getPieces();
        AllPieces piece = null;
        for(AllPieces piece1 : pieces)
            if(piece1.getId() == id)
                piece = piece1;
        return  piece;
    }

    public Cell[][] getCells(){ return this.cells; }
}
