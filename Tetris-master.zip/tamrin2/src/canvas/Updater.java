package canvas;

import pieces.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Updater {
    private static GameState gameState = GameState.getInstance();

    public static void updateMoveDown(){
        gameState = GameState.getInstance();
        AllPieces piece = gameState.getCurrentPiece();

        if(piece == null){
            piece = PieceCreater.generatePiece();
            gameState.setCurrentPiece(piece);
            gameState.addPiece(piece);
            gameState.getBoard().update();
            return;
        }
        if(piece.canMoveDown(gameState.getBoard().getCells())){
            piece.moveDown();
            gameState.getBoard().update();
        }
        else{
            Cell[][] box = piece.getBox();
            int box_size = piece.getBoxSize();
            if(box[box_size-1][0].getX() < 0 || box[box_size-2][0].getX() < 0){
                updateGameOver();
                return;
            }
            gameState.setScore(gameState.getScore() + Constants.LEVEL_FINISH_SCORE);
            Board board = gameState.getBoard();
            while(true){
                if(board.removeRow()){
                    SoundPlayer.playSound("remove.wav");
                    board.update();
                    gameState.setScore(gameState.getScore() + Constants.ROW_DESTRUCTION_SCORE);
                    continue;
                }
                board.update();
                break;
            }
            gameState.setCurrentPiece(null);
            gameState.getBoard().update();
        }
    }

    public static void updateGameOver(){
        gameState = GameState.getInstance();
        gameState.setGameOver(true);
        ArrayList<Integer> scores = FileFunctions.bestScores();
        scores.add(gameState.getScore());
        Collections.sort(scores);
        if(scores.size() > Constants.NUMBER_OF_BEST_SCORES)
            scores.remove(0);
        FileFunctions.writeBestScores(scores);
        SoundPlayer.playSound("gameover.wav");
    }

    public static void updateMoveHorizontal(int x){
        gameState = GameState.getInstance();
        if(gameState.getCurrentPiece() == null)
            return;
        if(gameState.getCurrentPiece().canMoveHorizontal(x, gameState.getBoard().getCells())) {
            gameState.getCurrentPiece().moveHorizontal(x);
            gameState.getBoard().update();
            SoundPlayer.playSound("move.wav");
        }
    }

    public static void updateRotate(){
        gameState = GameState.getInstance();
        if(gameState.getCurrentPiece() == null)
            return;
        if(gameState.getCurrentPiece().canRotate()) {
            gameState.getCurrentPiece().setBox(gameState.getCurrentPiece().rotatePiece());
            gameState.getBoard().update();
            SoundPlayer.playSound("rotate.wav");
        }
    }

    public static void updateTobe(){
        gameState = GameState.getInstance();
        gameState.removePiece(gameState.getCurrentPiece());
        gameState.setCurrentPiece(gameState.getCurrentPieceClone());
        gameState.addPiece(gameState.getCurrentPiece());
        gameState.getBoard().update();
        SoundPlayer.playSound("tobe.wav");
    }
}