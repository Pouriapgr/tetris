package pieces;

public class RightDuck extends Pieces {
    public RightDuck(int id, int box_size){
        super(id, box_size);
        box[2][0].setColor(color);
        box[2][1].setColor(color);
        box[1][1].setColor(color);
        box[1][2].setColor(color);
    }
}
