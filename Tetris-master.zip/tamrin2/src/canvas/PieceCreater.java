package canvas;

import pieces.*;

import java.util.Random;

public class PieceCreater {
    private static GameState gameState = GameState.getInstance();

    public  static AllPieces generatePiece(){
        gameState = GameState.getInstance();

        Random random = new Random(Double.doubleToLongBits(Math.random()));
        int x = (random.nextInt() % 7 + 7) % 7;
        int y = (random.nextInt() % 4 + 4) % 4;
        AllPieces piece = null;
        switch (x){
            case 0:
                piece = new LeftDuck(gameState.getPieceId() , 3);
                gameState.addPieceId();
                gameState.setCurrentPiece(piece);
                return piece;

            case 1:
                piece = new LeftLeg(gameState.getPieceId(), 3);
                gameState.addPieceId();
                gameState.setCurrentPiece(piece);
                return piece;

            case 2:
                piece = new Mountian(gameState.getPieceId(), 3);
                gameState.addPieceId();
                gameState.setCurrentPiece(piece);
                return piece;

            case 3:
                piece = new RightDuck(gameState.getPieceId(), 3);
                gameState.addPieceId();
                gameState.setCurrentPiece(piece);
                return piece;

            case 4:
                piece = new RightLeg(gameState.getPieceId(), 3);
                gameState.addPieceId();
                gameState.setCurrentPiece(piece);
                return piece;

            case 5:
                piece = new Stick(gameState.getPieceId(), 4);
                gameState.addPieceId();
                gameState.setCurrentPiece(piece);
                return piece;

            default:
                piece = new Window(gameState.getPieceId(), 2);
                gameState.addPieceId();
                gameState.setCurrentPiece(piece);
                return piece;
        }
    }
}