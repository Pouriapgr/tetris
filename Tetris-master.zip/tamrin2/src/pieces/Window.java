package pieces;

import canvas.Cell;
import canvas.Constants;
import canvas.GameState;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class Window extends AllPieces{

    public Window(int id, int box_size){
        super(id, box_size);
        box[0][0].setColor(color);
        box[1][1].setColor(color);
        box[0][1].setColor(color);
        box[1][0].setColor(color);
    }

    @Override
    public boolean canRotate(){
        return true;
    }

    @Override
    public Cell[][] rotatePiece(){
        return box;
    }
}
