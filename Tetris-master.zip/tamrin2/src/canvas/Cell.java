package canvas;

import java.awt.*;
import java.util.ArrayList;

public class Cell {
    private int x;
    private int y;
    final private int i1,i2;
    final private int WEIDTH;
    final private int height;
    private int id;
    private boolean occupied ;
    private Color color;

    public Cell(int x, int y, int i1, int i2, int WEIDTH, int height, Color color, boolean occupied, int id){
        this.x = x;
        this.y = y;
        this.i1 = i1;
        this.i2 = i2;
        this.WEIDTH = WEIDTH;
        this.height = height;
        this.id = id;
        this.color = color;
        this.occupied = occupied;
    }

    public static int getPositionI1(int x){
        if(x < 0)
            return -200;
        int position = Constants.TABLE_I1;
        for(int i = 1; i < x; i++)
            position += Constants.CELL_WEIDTH + Constants.CELL_SEPERATOR;
        return position;
    }

    public static int getPositionI2(int y){
        if(y < 0)
            return -200;
        int position = Constants.TABLE_I2;
        for(int i = 1; i < y; i++)
            position += Constants.CELL_HEIGHT + Constants.CELL_SEPERATOR;
        return position;
    }

    public int getX() {
        return this.x;
    }
    public int getY() {
        return this.y;
    }
    public int getI1() {
        return this.i1;
    }
    public int getI2() {
        return this.i2;
    }
    public int getWEIDTH() {
        return this.WEIDTH;
    }
    public int getId() {
        return this.id;
    }
    public int getHeight() {
        return this.height;
    }
    public Color getColor() {
        return this.color;
    }
    public boolean getOccupied() {
        return this.occupied;
    }

    public void setColor(Color color) {
        ArrayList<Color> allcolors = new ArrayList<>();
        allcolors.add(Color.BLUE);
        allcolors.add(Color.ORANGE);
        allcolors.add(Color.CYAN);
        allcolors.add(Color.GREEN);
        allcolors.add(Color.MAGENTA);
        allcolors.add(Color.RED);
        allcolors.add(Color.YELLOW);
        allcolors.add(Color.WHITE);
        for(Color color1:allcolors)
            if(color1.equals(color))
                this.color = color1;
        if(color.equals(Constants.CELL_INITIAL_COLOR))
            this.setOccupied(false);
        else
            this.setOccupied(true);
    }

    public void setCell(Cell cell1){ this.setColor(cell1.getColor()); }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setId(int id) { this.id = id; }
    public void setOccupied(boolean occupied) { this.occupied = occupied; }
}
