package pieces;

public class LeftLeg extends Pieces {
    public LeftLeg(int id, int box_size){
        super(id, box_size);
        box[0][1].setColor(color);
        box[1][1].setColor(color);
        box[2][1].setColor(color);
        box[2][0].setColor(color);
    }
}
