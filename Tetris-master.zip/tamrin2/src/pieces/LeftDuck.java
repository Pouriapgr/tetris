package pieces;

public class LeftDuck extends Pieces {
    public LeftDuck(int id, int box_size){
        super(id, box_size);
        box[1][0].setColor(color);
        box[1][1].setColor(color);
        box[2][1].setColor(color);
        box[2][2].setColor(color);
    }
}
