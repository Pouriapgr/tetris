package pieces;

public class Mountian extends Pieces {
    public Mountian(int id, int box_size){
        super(id, box_size);
        box[1][1].setColor(color);
        box[2][1].setColor(color);
        box[2][0].setColor(color);
        box[2][2].setColor(color);
    }
}
