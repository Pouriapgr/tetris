package pieces;

import canvas.Cell;
import canvas.Constants;
import canvas.GameState;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public abstract class AllPieces {
    protected GameState gameState = GameState.getInstance();
    protected Cell[][] box;
    protected Color color;
    final private int id;
    final protected int box_size;
    protected int left_column;

    public AllPieces(int id, int box_size){
        gameState = GameState.getInstance();
        this.id = id;
        this.box_size = box_size;
        this.color = generateRandomColor();
        this.left_column = generateRandomColumn();
        this.box = new Cell[box_size][box_size];

        for(int i = 0; i < box_size; i++){
            for(int j = 0; j < box_size; j++){
                box[i][j] = new Cell(i - box_size , left_column + j, -200, -200, Constants.CELL_WEIDTH,
                        Constants.CELL_HEIGHT, Constants.CELL_INITIAL_COLOR, false, id);
            }
        }
    }

    private Color generateRandomColor(){
        ArrayList<Color> allcolors = new ArrayList<>();
        allcolors.add(Color.BLUE);
        allcolors.add(Color.ORANGE);
        allcolors.add(Color.CYAN);
        allcolors.add(Color.GREEN);
        allcolors.add(Color.MAGENTA);
        allcolors.add(Color.RED);
        allcolors.add(Color.YELLOW);

        Random random = new Random(Double.doubleToLongBits(Math.random()));
        int x = (random.nextInt() % (allcolors.size()) + allcolors.size()) % allcolors.size();
        return allcolors.get(x);
    }

    private int generateRandomColumn(){
        Random random = new Random(Double.doubleToLongBits(Math.random()));
        int MOD = Constants.TABLE_WEIDTH + 1 - box_size;
        int y = (random.nextInt() % (MOD) + MOD) % MOD;
        return y;
    }

    public boolean isPresent(){
        for(int i = 0; i < box_size; i++)
            for(int j = 0; j < box_size; j++)
                if(box[i][j].getOccupied())
                    return true;
        return false;
    }

    public boolean canMoveDown(Cell[][] cells) {
        for(int i = 0; i < box_size; i++) {
            for (int j = 0; j < box_size; j++) {
                if(box[i][j].getOccupied() == false)
                    continue;

                int X = box[i][j].getX() + 1;
                int Y = box[i][j].getY();
                if(X < 0 || Y < 0 || Y >= Constants.TABLE_WEIDTH)
                    continue;
                if(X == Constants.TABLE_HEIGHT)
                    return false;
                if(cells[X][Y].getId() == 0)
                    continue;
                if(cells[X][Y].getOccupied() && cells[X][Y].getId() != this.id)
                    return false;
            }
        }
        return true;
    }

    public void moveDown(){
        for(int i = 0; i < box_size; i++) {
            for (int j = 0; j < box_size; j++) {
                box[i][j].setX(box[i][j].getX() + 1);
            }
        }
    }

    public boolean canMoveHorizontal(int dif, Cell[][] cells){
        for(int i = 0; i < box_size; i++) {
            for (int j = 0; j < box_size; j++) {
                if(box[i][j].getOccupied() == false)
                    continue;
                int X = box[i][j].getX();
                int Y = box[i][j].getY() + dif;

                if(Y < 0 || Y >= Constants.TABLE_WEIDTH || X < 0 || X == Constants.TABLE_HEIGHT)
                    return false;
                if(cells[X][Y].getId() == 0)
                    continue;
                if(cells[X][Y].getOccupied() && cells[X][Y].getId() != this.id)
                    return false;
            }
        }
        return true;
    }

    public void moveHorizontal(int dif){
        for(int i = 0; i < box_size; i++)
            for (int j = 0; j < box_size; j++)
                box[i][j].setY(box[i][j].getY() + dif);
    }

    public AllPieces clonePiece(){
        AllPieces piece = null;
        if(this.box_size == 2)
            piece = new Window(this.id, this.box_size);
        else if(this.box_size == 3)
            piece = new Pieces(this.id, this.box_size);
        else
            piece = new Stick(this.id, this.box_size);
        piece.color = color;
        piece.left_column = this.left_column;
        for(int i = 0; i < box_size; i++){
            for(int j = 0; j < box_size; j++){
                piece.box[i][j] = new Cell(i - box_size , left_column + j, -200, -200,
                        Constants.CELL_WEIDTH, Constants.CELL_HEIGHT, Constants.CELL_INITIAL_COLOR, false, id);
            }
        }
        for(int i = 0; i < box_size; i++)
            for(int j = 0; j < box_size; j++)
                piece.box[i][j].setCell(this.box[i][j]);
        return piece;
    }

    public Color getColor() { return color; }
    public Cell[][] getBox(){ return box; }
    public int getLeftColumn(){ return left_column; }
    public int getBoxSize(){ return box_size; }
    public int getId(){ return id; }

    public void setLeftColumn(int left_column){
        this.left_column = left_column;
    }
    public void setBox(Cell[][] cells){
        box = cells;
    }

    public abstract boolean canRotate();
    public abstract Cell[][] rotatePiece();
}
