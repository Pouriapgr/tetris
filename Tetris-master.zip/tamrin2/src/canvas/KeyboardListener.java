package canvas;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyboardListener implements KeyListener {

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_LEFT:
                Updater.updateMoveHorizontal(-1);
                break;
            case KeyEvent.VK_RIGHT:
                Updater.updateMoveHorizontal(+1);
                break;
            case KeyEvent.VK_SPACE:
                Updater.updateRotate();
                break;
            case KeyEvent.VK_BACK_SPACE:
                Updater.updateTobe();
                break;

            default:
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}
}
