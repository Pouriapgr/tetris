package canvas;

import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class Canvas extends JComponent {
    private Drawer drawer;
    private GameState gameState = GameState.getInstance();

    public Canvas(){
        addKeyListener(new KeyboardListener());
        Timer timer = new Timer();
        TimerTask timerTask = new Ticker();
        timer.scheduleAtFixedRate(timerTask, Constants.DELAY_TIME, Constants.TICK_TIME);
    }

    @Override
    protected void paintComponent(Graphics graphics){
        super.paintComponent(graphics);
        gameState = GameState.getInstance();
        Graphics2D graphics2D = (Graphics2D) graphics;
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if(drawer == null) { drawer = new Drawer(); }
        drawer.setGraphics2D(graphics2D);
        requestFocus();

        if(gameState.getGameOver())
            drawer.drawGameOver();
        else
            drawer.drawGameState();
    }

    private class Ticker extends TimerTask{
        @Override
        public void run(){
            gameState = GameState.getInstance();
            if(gameState.getGameOver() == false)
                update();
            repaint();
        }
    }
    public void update(){
        gameState = GameState.getInstance();
        Updater.updateMoveDown();
        gameState.getBoard().update();
    }
}
