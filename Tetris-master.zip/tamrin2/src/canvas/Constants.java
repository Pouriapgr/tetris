package canvas;

import java.awt.*;

public class Constants {
    final public static int FRAME_HEIGHT = 800;
    final public static int FRAME_WIEDTH = 600;

    final public static Color CELL_INITIAL_COLOR = Color.lightGray;
    final public static int CELL_HEIGHT = 30;
    final public static int CELL_WEIDTH = 30;
    final public static int CELL_SEPERATOR = 2;

    final public static int TICK_TIME = 1000;
    final public static int DELAY_TIME = 200;

    final public static Color BACKGROUND_COLOR = Color.black;
    final public static int BACKGROUND_I1 = 1;
    final public static int BACKGROUND_I2 = 1;
    final public static int BACKGROUND_HEIGHT = 800;
    final public static int BACKGROUND_WEIDTH = 400;

    final public static int TABLE_WEIDTH = 10;
    final public static int TABLE_HEIGHT = 20;
    final public static int TABLE_I1 = (BACKGROUND_WEIDTH - (TABLE_WEIDTH)*(CELL_WEIDTH + CELL_SEPERATOR) + CELL_SEPERATOR)/2;
    final public static int TABLE_I2 = (BACKGROUND_HEIGHT - (TABLE_HEIGHT)*(CELL_HEIGHT + 2 * CELL_SEPERATOR) )/2;

    final public static String FONT_NAME = "Helvetica";
    final public static int FONT_SIZE = 40;

    final public static int LEVEL_FINISH_SCORE = 1;
    final public static int ROW_DESTRUCTION_SCORE = 10;

    final public static int NUMBER_OF_BEST_SCORES = 8;
}
